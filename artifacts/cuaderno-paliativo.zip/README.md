# Cuaderno de guardia

Herramienta de consulta para cuidados paliativos. Una sola página, sin servidor: los datos quedan en el navegador.

## Publicar en GitHub Pages

1. Crear un repositorio público.
2. Subir `index.html` y la carpeta `laminas/` a la raíz. No separar las imágenes: la página las busca en `laminas/`.
3. Settings → Pages → Branch `main` / root.
4. La dirección queda en `https://usuario.github.io/nombre-del-repo/`.

No hace falta build ni dependencias.
